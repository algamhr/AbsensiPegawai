<?php

$con = mysqli_connect("localhost","simdes_alga","ajaccyf14KG8eDuW","simdes_alga");
$response = array();

if(isset($_POST['id']) && isset($_POST['nip']) && isset($_POST['nidn']) && isset($_POST['nama']) && isset($_POST['email']) && isset($_POST['fakultas']) && isset($_POST['jurusan']) && isset($_POST['no_hp'])) {

  if($con){
      $id = $_POST['id'];
      $nip = $_POST['nip'];
      $nidn = $_POST['nidn'];
      $nama = $_POST['nama'];
      $email = $_POST['email'];
      $jurusan = $_POST['jurusan'];
      $fakultas = $_POST['fakultas'];
      $no_hp = $_POST['no_hp'];

      header("Content-Type: JSON");

      $sql = "UPDATE user SET nip = '$nip', nidn = '$nidn', nama = '$nama', email = '$email', 
              jurusan = '$jurusan', fakultas = '$fakultas', no_hp = '$no_hp' WHERE id = $id";

      $result = mysqli_query($con, $sql);

      if($result){
          $sql2 = "SELECT id, nip, nidn, nama, email, jurusan, fakultas, no_hp FROM user WHERE id = '$id'";

          $result2 = mysqli_query($con, $sql2);
          // $i = 0;
          if(mysqli_num_rows($result2) == 1){
              while($row = mysqli_fetch_assoc($result2)){
                  $response['status'] = true;
                  $response['nip'] = $row['nip'];
                  $response['nidn'] = $row['nidn'];
                  $response['nama'] = $row['nama'];
                  $response['email'] = $row['email'];
                  $response['jurusan'] = $row['jurusan'];
                  $response['fakultas'] = $row['fakultas'];
                  $response['no_hp'] = $row['no_hp'];

                  $response['status'] = true;
                  $response['message'] = "Update data berhasil.";
              }
          } else {
              $response['status'] = false;
              $response['message'] = "Data gagal dimasukkan.";
          }
      } else {
          $response['status'] = false;
          $response['message'] = "Username tidak ditemukan";
      }
      echo json_encode($response, JSON_PRETTY_PRINT);
  } else {
      $response['status'] = false;
      echo json_encode($response, JSON_PRETTY_PRINT);
  }
}

?>