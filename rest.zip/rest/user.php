<?php

//dapatkan nip atau nidn dan password dari headers
$con = mysqli_connect("localhost","simdes_alga","ajaccyf14KG8eDuW","simdes_alga");
$response = array();

if($con){
    $sql = "select * from user";
    $result = mysqli_query($con, $sql);
    if($result){
        header("Content-Type: JSON");
        $i = 0;
        while($row = mysqli_fetch_assoc($result)){
            $response[$i]['id'] = $row ['id'];
            $response[$i]['nip'] = $row ['nip'];
            $response[$i]['nidn'] = $row ['nidn'];
            $response[$i]['level'] = $row ['level'];
            $response[$i]['nama'] = $row ['nama'];
            $response[$i]['email'] = $row ['email'];
            $response[$i]['jenis_kelamin'] = $row ['jenis_kelamin'];
            $response[$i]['jurusan'] = $row ['jurusan'];
            $response[$i]['fakultas'] = $row ['fakultas'];
            $response[$i]['no_hp'] = $row ['no_hp'];
            $i++;
        }
        echo json_encode($response, JSON_PRETTY_PRINT);
    }
} else {
    echo "Database Connection Failed";
}

?>