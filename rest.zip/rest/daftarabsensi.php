<?php

//dapatkan nip atau nidn dan password dari headers
$con = mysqli_connect("localhost","simdes_alga","ajaccyf14KG8eDuW","simdes_alga");
$response = array();

$nidn = $_GET['nidn'];

if($con){
    $sql = "SELECT ab.id, ab.user_id, ab.jam, ab.lokasi_id, ab.keterangan, 
    usr.nama, usr.nidn, 
    lk.lokasi 
    FROM absensi ab 
    LEFT JOIN user usr ON ab.user_id = usr.id 
    LEFT JOIN lokasi lk ON ab.lokasi_id = lk.id 
    WHERE usr.nidn = '$nidn' 
    ORDER BY ab.jam DESC";
    
    $result = mysqli_query($con, $sql);
    if($result){
        header("Content-Type: JSON");
        $i = 0;
        while($row = mysqli_fetch_assoc($result)){
            $response['data'][$i]['ab.id']          = $row ['id'];
            $response['data'][$i]['usr.nidn']       = $row ['nidn'];
            $response['data'][$i]['usr.nama']       = $row ['nama'];
            $response['data'][$i]['ab.jam']         = $row ['jam'];
            $response['data'][$i]['lk.lokasi']      = $row ['lokasi'];
            $response['data'][$i]['ab.keterangan']  = $row ['keterangan'];  
            $i++;  
        }
        $response['status'] = true;
        $response['message'] = "Berhasil";
    } else {
        $response['status'] = false;
        $response['message'] = "No data";
    } 
    echo json_encode($response, JSON_PRETTY_PRINT);
} else {
    echo "Database Connection Failed";
}

?>