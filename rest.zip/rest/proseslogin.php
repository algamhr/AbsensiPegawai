<?php
$con = mysqli_connect("localhost","simdes_alga","ajaccyf14KG8eDuW","simdes_alga");
$response = array();

$username = isset($_POST['username']) ? $_POST['username'] : "";
$password = isset($_POST['password']) ? $_POST['password'] : "";
$fcm_token = isset($_POST['fcm_token']) ? $_POST['fcm_token'] : "";


if($con){
    header("Content-Type: JSON");
    $sql = "SELECT usr.id, usr.nip, usr.nidn, usr.password,
            usrl.level
            FROM user usr
            LEFT JOIN userlevel usrl
            ON usr.level_id = usrl.id
            WHERE 
            (usr.nip = '$username' OR usr.nidn = '$username') AND usr.password = '$password'
            LIMIT 1";
    $result = mysqli_query($con, $sql);
    if($result){
        $i = 0;
        if(mysqli_num_rows($result) > 0){
          	$row = mysqli_fetch_assoc($result);
            $response['status'] = true;
            $response['message'] = "Login Berhasil";
          	$response['usr.id'] = $row ['id'];
            $response['usr.nip'] = $row ['nip'];
            $response['usr.nidn'] = $row ['nidn'];
            $response['usrl.level'] = $row['level'];
          	$id = $row ['id'];
          	mysqli_query($con, "UPDATE user SET fcm_token = '$fcm_token' WHERE id = '$id'");
        } else {
            $response['status'] = false;
            $response['message'] = "Username dan password tidak cocok";
        }
    } else {
        $response['status'] = false;
        $response['message'] = "Username tidak ditemukan";
    }
    echo json_encode($response, JSON_PRETTY_PRINT);
} else {
    $response['status'] = false;
    $response['message'] = "Terjadi Kesalahan";
    echo json_encode($response, JSON_PRETTY_PRINT);
}

?>