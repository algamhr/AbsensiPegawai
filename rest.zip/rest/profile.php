<?php

//dapatkan nip atau nidn dan password dari headers
$con = mysqli_connect("localhost","simdes_alga","ajaccyf14KG8eDuW","simdes_alga");
$response = array();

$id = $_GET['id'];

if($con){
    $sql = "SELECT usr.id, usr.nip, usr.nidn, usr.nama, usr.email, usr.jurusan, usr.fakultas, usr.no_hp
            FROM user usr
            WHERE usr.id = '$id'";
    $result = mysqli_query($con, $sql);
    if($result){
        header("Content-Type: JSON");
        $i = 0;
        $row = mysqli_fetch_assoc($result);
      	$response['status'] = true;
        $response['usr.id'] = $row ['id'];
        $response['usr.nip'] = $row ['nip'];
        $response['usr.nidn'] = $row ['nidn'];
        $response['usr.nama'] = $row ['nama'];
        $response['usr.email'] = $row ['email'];
        $response['usr.jurusan'] = $row ['jurusan'];
        $response['usr.fakultas'] = $row ['fakultas'];
        $response['usr.no_hp'] = $row ['no_hp'];
        echo json_encode($response, JSON_PRETTY_PRINT);
    }
} else {
    echo "Database Connection Failed";
}

?>