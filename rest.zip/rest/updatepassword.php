<?php

$con = mysqli_connect("localhost","simdes_alga","ajaccyf14KG8eDuW","simdes_alga");
$response = array();

if(isset($_POST['id']) && isset($_POST['oldpassword']) && isset($_POST['password'])){
    if($con){
        $id = $_POST['id'];
        $oldpassword = $_POST['oldpassword'];
        $password = $_POST['password'];
        
        header("Content-Type: JSON");

        $sqlpassword = "SELECT password FROM user WHERE id = '$id'";
        $resultcheck = mysqli_query($con, $sqlpassword);

        while ($row = mysqli_fetch_array($resultcheck)) {
            $old_password = $row['password'];
        }

        if($old_password == $oldpassword){
            $response['status'] = true;
            $response['message'] = "Password lama sudah sinkron.";

            $sql = "UPDATE user SET password = '$password' WHERE id = '$id'";

            $result = mysqli_query($con, $sql);
    
            if($result){
                $sql2 = "SELECT password FROM user WHERE id = '$id'";
    
                $result2 = mysqli_query($con, $sql2);
                // $i = 0;
                if(mysqli_num_rows($result2) > 0){
                    while($row = mysqli_fetch_assoc($result2)){
                        $response['status'] = true;
                        $response['password'] = $row['password'];

                        $response['status'] = true;
                        $response['message'] = "Update password berhasil.";
                    }
                } else {
                    $response['status'] = false;
                    $response['message'] = "Data gagal dimasukkan.";
                }
            } else {
                $response['status'] = false;
                $response['message'] = "Username tidak ditemukan";
            }
        } else {
            $response['status'] = false;
            $response['message'] = "Password lama Anda salah.";
        }
        echo json_encode($response, JSON_PRETTY_PRINT);
    } else {
        $response['status'] = false;
        $response['message'] = "Gagal";
        echo json_encode($response, JSON_PRETTY_PRINT);
    } 
} else {
    $response['status'] = false;
    $response['message'] = "Gagal Utama";
    echo json_encode($response, JSON_PRETTY_PRINT);
}

?>