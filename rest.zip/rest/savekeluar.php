<?php
date_default_timezone_set("Asia/Jakarta");
$con = mysqli_connect("localhost","simdes_alga","ajaccyf14KG8eDuW","simdes_alga");
$response = array();

if(isset($_POST['username']) && isset($_POST['latitude']) && isset($_POST['longitude'])){
	if($con){
      $username = $_POST['username'];
      $latitude = $_POST['latitude'];
      $longitude = $_POST['longitude'];

      header("Content-Type: JSON");
      $sql = "SELECT id, lokasi 
              FROM lokasi 
              WHERE ST_Contains(area, GeomFromText('POINT($longitude $latitude)'))";

      $result = mysqli_query($con, $sql);
      if($result){
          if(mysqli_num_rows($result) == 1){
              $row = mysqli_fetch_assoc($result);
              $id_lokasi = $row['id'];
              $nama_lokasi = $row['lokasi'];
              $jam = Date('Y-m-d H:i:s');
              $keterangan = "Pulang";
              $time  = Date('H:i:s', strtotime($jam));
              if(strtotime($time) >= strtotime("14:30:00") && strtotime($time) < strtotime("20:15:00")){
                  $sql_insert = "INSERT INTO absensi (user_id, jam, lokasi_id, keterangan) VALUES ($username, '$jam', $id_lokasi, '$keterangan')";
                  $save = mysqli_query($con, $sql_insert);
                  if($save){
                      $response['status'] = true;
                      $response['message'] = "Berhasil absensi $keterangan pada $jam di lokasi $nama_lokasi";
                  } else {
                      $response['status'] = false;
                      $response['message'] = "Gagal menyimpan";    
                  }
              } else {
                  $response['status'] = false;
                  $response['message'] = "Tidak bisa absen karena sudah lewat jam pulang.";     
              }            
          } else {
              $response['status'] = false;
              $response['message'] = "Titik lokasi tidak terdaftar, silahkan absen ulang.";    
          }
      } else {
          $response['status'] = false;
          $response['message'] = "Terjadi kesalahan saat menvalidasi lokasi";
      }
      echo json_encode($response, JSON_PRETTY_PRINT);
    } else {
      $response['status'] = false;
      echo json_encode($response, JSON_PRETTY_PRINT);
    }
	} else {
  		header("Content-Type: JSON");
  		$response['status'] = false;
  		echo json_encode($response, JSON_PRETTY_PRINT); 
 }

?>