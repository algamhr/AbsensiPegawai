<?php

//dapatkan nip atau nidn dan password dari headers
$con = mysqli_connect("localhost","simdes_alga","ajaccyf14KG8eDuW","simdes_alga");
$response = array();

if($con){
    $sql = "SELECT usr.id, usr.nama, usr.nidn
                FROM user usr";
    $result = mysqli_query($con, $sql);
    if($result){
        header("Content-Type: JSON");
        $i = 0;
        while($row = mysqli_fetch_assoc($result)){
            $response['data'][$i]['usr.id']         = $row ['id'];
            $response['data'][$i]['usr.nidn']       = $row ['nidn'];
            $response['data'][$i]['usr.nama']       = $row ['nama'];
          	$i++;
        }
        $response['status'] = true;
        $response['message'] = "Berhasil";
    } else {
        $response['status'] = false;
        $response['message'] = "No data";
    } 
    echo json_encode($response, JSON_PRETTY_PRINT);
} else {
    echo "Database Connection Failed";
}